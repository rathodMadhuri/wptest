=== Plugin Name ===
Contributors: MadhuriRahod
Tags: contributors, post,metabox
Requires at least: 5
Tested up to: 5
Stable tag: 5
Requires PHP: 7

Plugin is used to add multiple contributors to the post and show that in frontend along with content and gravatar of contributors.

== Description ==

Plugin is used to add multiple contributors to the post and show that in frontend along with content and gravatar of contributors.

= Wp multiple contributors features =


* Add metabox to the post to add more contributors to post.
* Shows the contributors list after post content.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload wp-multiple-contributers.zip to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Once plugin gets activated, metabox will be available in posts.

== Frequently asked questions ==

=1. How do I assign multiple contributors?=
a) Find 'Posts' menu in your WordPress admin panel. Click on "Edit" option from the post list.
b) Check Contributors metabox and select multple checkboxes of users .

=2. Where I can find the contributor list?=
Contributor list or Contributor name and avatar you can find at the end of post content in listing as well as post single page


== Screenshots ==

1. screenshot-1.png 
	Contributor Metabox.	
2. screenshot-2.png 
	Front end matabox list.